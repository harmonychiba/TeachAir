<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Belonging
 *
 * @author harmonychiba
 */
class Belonging extends AppModel{
    //put your code here
    public $name = "Belonging";
}

?>
