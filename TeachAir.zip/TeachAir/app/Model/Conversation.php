<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Conversation
 *
 * @author harmonychiba
 */
class Conversation extends AppModel{
    //put your code here
    public $name = "Conversation";
}

?>
