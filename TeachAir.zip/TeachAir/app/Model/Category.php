<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Category
 *
 * @author harmonychiba
 */
class Category extends AppModel{
    //put your code here
    public $name = "Category";
}

?>
