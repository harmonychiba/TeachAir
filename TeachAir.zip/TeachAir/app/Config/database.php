<?php
class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'harmonychiba',
		'password' => 'harmonyisno1',
		'database' => 'teachair',
		'prefix' => '',
		'encoding' => 'utf8'
	);
}
